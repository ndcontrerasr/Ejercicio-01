from django.urls import path, include

urlpatterns = [
    path('', include('swarch2022i_ms.urls')),
]

