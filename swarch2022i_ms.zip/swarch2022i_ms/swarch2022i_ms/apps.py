from django.apps import AppConfig

class Swarch2022iConfig(AppConfig):
    name = 'swarch2022i_ms'
